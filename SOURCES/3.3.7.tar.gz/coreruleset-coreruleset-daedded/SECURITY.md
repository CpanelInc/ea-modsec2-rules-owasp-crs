# Security Policy

See policy here: https://github.com/coreruleset/coreruleset/blob/v4.0/dev/SECURITY.md

